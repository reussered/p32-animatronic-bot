# P32 Auto-Build System

The P32 Auto-Build system automatically selects the correct PlatformIO environment based on controller specifications in your bot configuration JSON files.

## How It Works

1. **Bot Configuration** defines which subsystems to include
2. **Subsystem JSON** specifies the `controller` type (e.g., "ESP32_S3_DEVKITC_1")
3. **Auto-Build Script** maps controllers to PlatformIO environments
4. **Build Process** generates tables and compiles for each subsystem

## Controller Mappings

| Controller Type | PlatformIO Environment | ESP32 Board |
|-----------------|----------------------|-------------|
| ESP32_S3_DEVKITC_1 | goblin_head | esp32-s3-devkitc-1 |
| ESP32_S3_DEVKIT | goblin_head | esp32-s3-devkitc-1 |
| ESP32_S3_R8N16 | goblin_head | esp32-s3-devkitc-1 |
| ESP32_C3_MINI | left_arm | esp32-c3-devkitm-1 |
| ESP32_C3_DEVKITM_1 | left_arm | esp32-c3-devkitm-1 |
| ESP32 | left_arm_advanced | esp32dev |
| ESP32-S3 | goblin_head | esp32-s3-devkitc-1 |

## Usage

### Build a Bot

```bash
# Using Python script
python auto_build.py test_bot

# Using batch script (Windows)
.\build_bot.bat test_bot
```

### Manual Build (Legacy)

```bash
# Generate tables
python tools/generate_tables.py test_bot src

# Build with specific environment
pio run -c platformio_multi_variant.ini -e goblin_head
```

## Bot Configuration Structure

```json
{
  "name": "test_bot",
  "components": [
    "config/subsystems/test_head.json"
  ]
}
```

## Subsystem Configuration Structure

```json
{
  "name": "test_head",
  "controller": "ESP32_S3_DEVKITC_1",
  "components": [
    "config/components/positioned/goblin_left_eye.json",
    "config/components/positioned/goblin_right_eye.json"
  ]
}
```

## Multi-Subsystem Bots

The system supports bots with multiple subsystems, each potentially running on different ESP32 chips:

```json
{
  "name": "full_goblin",
  "components": [
    "config/subsystems/goblin_head.json",     // ESP32-S3
    "config/subsystems/goblin_torso.json",    // ESP32-S3
    "config/subsystems/left_arm.json",        // ESP32-C3
    "config/subsystems/right_arm.json"        // ESP32-C3
  ]
}
```

Each subsystem will be built with its appropriate PlatformIO environment automatically.

## Adding New Controller Mappings

Edit the `CONTROLLER_MAPPING` dictionary in `auto_build.py`:

```python
CONTROLLER_MAPPING = {
    "NEW_CONTROLLER_TYPE": "platformio_environment_name",
    # ...
}
```
 
 